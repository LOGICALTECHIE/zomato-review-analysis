import numpy as np
from flask import Flask, request, jsonify, render_template
from tensorflow.keras.models import load_model
from  sklearn.feature_extraction.text import CountVectorizer
import pickle
app = Flask(__name__)
model = load_model('model.h5')
loaded=CountVectorizer(decode_error="replace",vocabulary=pickle.load(open("feature.pkl", "rb")))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    da=request.form['Review']
    da= da.split("delimiter")
    result=model.predict(loaded.transform(da))
    print(result)
    prediction=result>0.5
    print(prediction)
    output=result
    if(result>0.5):
        op="Positive"
    else:
        op="Negative"
   
   
    
    return render_template('index.html', prediction_text='Review:{}'.format(op))


if __name__ == "__main__":
    app.run(debug=True)
